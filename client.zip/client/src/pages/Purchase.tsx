import PurchasePage from "../components/PurchasePage/PurchasePage";

const Purchase = () => {
  return <PurchasePage />
};

export default Purchase;