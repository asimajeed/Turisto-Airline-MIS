import SearchPage from "../components/SearchPage/SearchPage";

const Search = () => {
  return <SearchPage />;
};

export default Search;
